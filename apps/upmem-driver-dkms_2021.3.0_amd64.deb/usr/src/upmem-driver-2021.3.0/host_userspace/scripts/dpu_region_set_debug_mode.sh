#!/bin/bash

# Copyright 2020 UPMEM. All rights reserved.

RANK_PATH=$1
DEBUG_MODE=$2

if [ -z "$RANK_PATH" ]; then
       echo "path to rank must be provided"
       exit -1
fi

if ! [ -c "$RANK_PATH" ]; then
       echo "path to rank is invalid ($RANK_PATH)"
       exit -1
fi

if [[ "$DEBUG_MODE" != "0" && "$DEBUG_MODE" != "1" ]]; then
	echo "debug mode must be specified: 0 for disabling, 1 for enabling"
	exit -1
fi

SYSFS_REGION_PARENT_DEBUG_MODE_PATH="/sys"$(udevadm info -q path -n $RANK_PATH)"/debug_mode"

echo $DEBUG_MODE  > $SYSFS_REGION_PARENT_DEBUG_MODE_PATH
