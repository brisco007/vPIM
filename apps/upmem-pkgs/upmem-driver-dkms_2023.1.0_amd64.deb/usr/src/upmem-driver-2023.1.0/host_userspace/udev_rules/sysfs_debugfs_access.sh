#!/bin/bash
# Copyright 2020 UPMEM. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
#
# Alternatively, this software may be distributed under the terms of the
# GNU General Public License ("GPL") version 2 as published by the Free
# Software Foundation.

# fpga kc705 sysfs attributes that must be writable for group plugdev
fpga_kc705_attr=("activate_ila" "reset_ila" "spi_mode" "activate_filtering_ila" "activate_mram_bypass" "mram_refresh_emulation_period")
rank_device_path="/dev/dpu_rank"
debugfs_path=`awk -v debug="debugfs" '$1==debug {print $2}' /proc/mounts`
number_rank=0

# Grant access to debugfs...
chown :plugdev "$debugfs_path"
chmod g+rx "$debugfs_path"

while [ -c "$rank_device_path$number_rank" ]; do
	rank_sysfs_path=`udevadm info -q path -n $rank_device_path$number_rank`
	rank_sysfs_path="/sys$rank_sysfs_path"

	# update sysfs attribute's group and access rights
	for attr in "${fpga_kc705_attr[@]}"; do
		# attribute might not exist depending on the FW
		if [ -f "$rank_sysfs_path/$attr" ]; then
			chown :plugdev "$rank_sysfs_path/$attr"
			chmod g+w "$rank_sysfs_path/$attr"
		fi
	done

	# dpu_rank debugfs path
	rank_debugfs_path="$debugfs_path/dpu_rank$number_rank"

	# If debugfs is not mounted, dpu_rank entries are not created, so
	# check dpu_rank existence.
	if [ -d "$rank_debugfs_path" ]; then
		chown -R :plugdev "$rank_debugfs_path"
	fi

	number_rank=$((number_rank + 1))
done;


