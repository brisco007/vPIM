/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright 2020 UPMEM. All rights reserved. */
#ifndef DPU_REGION_DEV_INCLUDE_H
#define DPU_REGION_DEV_INCLUDE_H

#include "dpu_region.h"

#endif /* DPU_REGION_DEV_INCLUDE_H */
