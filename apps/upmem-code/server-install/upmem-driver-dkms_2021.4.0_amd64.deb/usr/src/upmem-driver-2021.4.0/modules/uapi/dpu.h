/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright 2020 UPMEM. All rights reserved. */
#ifndef DPU_H
#define DPU_H

struct dpu_rank_t;
struct dpu_t;

#endif /* DPU_H */